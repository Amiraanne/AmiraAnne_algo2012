#include "testApp.h"
#include "ofMain.h"

//--------------------------------------------------------------
void testApp::setup(){

	
	ofSetVerticalSync(true);
	ofBackground(30,30,30);
	ofEnableAlphaBlending();
	
// set the position of the rectangle:
//	
//	myRectangle.pos.x = 100;
//	myRectangle.pos.y = 50;
	
	for (int i = 0; i < numRectangles; i++) {
		
		rectangle[i].pos.x = ofGetWidth()/2;
		rectangle[i].pos.y = ofGetHeight()/2;
		
		rectangle[i].radiusSize = 5 + i;
		rectangle[i].color = ofRandom((255,23,0));
		rectangle[i].opacity = i;
		
		squared[i].catchUpSpeed = .2f;
	}
	
}

//--------------------------------------------------------------
void testApp::update(){
	rectangle[numRectangles].xenoToPoint(mouseX, mouseY);
	
	for (int i = 0; i < numRectangles; i++) {
		rectangle[i].xenoToPoint(rectangle[i-1].pos.x, rectangle[i-1].pos.y);
	}
	
}

//--------------------------------------------------------------
void testApp::draw(){
	
	for (int i=0; i<500; i++) {
		rectangle[i].draw();
	}

}

//--------------------------------------------------------------
void testApp::keyPressed  (int key){
}

//--------------------------------------------------------------
void testApp::keyReleased  (int key){
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){
}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){
}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){
}

//--------------------------------------------------------------
void testApp::mouseReleased(){
}
